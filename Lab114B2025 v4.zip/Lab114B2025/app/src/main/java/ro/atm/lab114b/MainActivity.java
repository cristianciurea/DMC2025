package ro.atm.lab114b;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_ADD = 100;

    List<Student> listaStudenti = new ArrayList<>();

    ListView listView;

    public static final int REQUEST_CODE_EDIT = 200;

    public static final String EDIT_STUDENT = "editStudent";

    public int poz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
/*        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });*/

        FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                startActivityForResult(intent, REQUEST_CODE_ADD);
            }
        });

        listView  = findViewById(R.id.listView);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                Student student = listaStudenti.get(position);
                ArrayAdapter adapter = (ArrayAdapter) listView.getAdapter();

                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Confirmare stergere")
                        .setMessage("Doriti stergerea?")
                        .setNegativeButton("NU", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(getApplicationContext(), "Nu am sters nimic!", Toast.LENGTH_SHORT).show();
                                dialogInterface.cancel();
                            }
                        })
                        .setPositiveButton("DA", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                listaStudenti.remove(student);

                                StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
                                database.getStudentDao().delete(student);

                                adapter.notifyDataSetChanged();
                                Toast.makeText(getApplicationContext(), "Am sters "+student.toString(), Toast.LENGTH_SHORT).show();
                                dialogInterface.cancel();
                            }
                        })
                        .create();

                dialog.show();

                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                poz = position;
                Intent intent = new Intent(getApplicationContext(), AddActivity.class);
                intent.putExtra(EDIT_STUDENT, listaStudenti.get(position));
                startActivityForResult(intent, REQUEST_CODE_EDIT);

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
        if(listaStudenti.size()==0)
            listaStudenti = database.getStudentDao().getAll();

        CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                R.layout.elem_listview, listaStudenti, getLayoutInflater())
        {
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);

                Student student1 = listaStudenti.get(position);
                TextView tvMedie = view.findViewById(R.id.tvMedie);
                if(student1.getMedieAnuala()>=5)
                    tvMedie.setTextColor(Color.GREEN);
                else
                    tvMedie.setTextColor(Color.RED);

                return view;
            }
        };

        listView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.meniu_principal, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==R.id.optiune1)
        {
            Intent intent = new Intent(getApplicationContext(), BNRActivity.class);
            startActivity(intent);
            return true;
        }
        else
        if(item.getItemId()==R.id.optiune2)
        {

            ExtractXML extractXML = new ExtractXML()
            {
                @Override
                protected void onPostExecute(InputStream inputStream) {
                    listaStudenti.addAll(this.studentList);

                    StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
                    database.getStudentDao().insert(this.studentList);

                    CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                            R.layout.elem_listview, listaStudenti, getLayoutInflater())
                    {
                        @NonNull
                        @Override
                        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                            View view = super.getView(position, convertView, parent);

                            Student student1 = listaStudenti.get(position);
                            TextView tvMedie = view.findViewById(R.id.tvMedie);
                            if(student1.getMedieAnuala()>=5)
                                tvMedie.setTextColor(Color.GREEN);
                            else
                                tvMedie.setTextColor(Color.RED);

                            return view;
                        }
                    };

                    listView.setAdapter(adapter);
                }
            };
            try {
                extractXML.execute(new URL("https://pastebin.com/raw/j6nS1Ce2"));
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }

            return true;
        }
        else
        if(item.getItemId()==R.id.optiune3)
        {
            ExtractJSON extractJSON = new ExtractJSON()
            {
                @Override
                protected void onPostExecute(String s) {
                    listaStudenti.addAll(this.studentListJSON);

                    StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
                    database.getStudentDao().insert(this.studentListJSON);

                    CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                            R.layout.elem_listview, listaStudenti, getLayoutInflater())
                    {
                        @NonNull
                        @Override
                        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                            View view = super.getView(position, convertView, parent);

                            Student student1 = listaStudenti.get(position);
                            TextView tvMedie = view.findViewById(R.id.tvMedie);
                            if(student1.getMedieAnuala()>=5)
                                tvMedie.setTextColor(Color.GREEN);
                            else
                                tvMedie.setTextColor(Color.RED);

                            return view;
                        }
                    };

                    listView.setAdapter(adapter);
                }
            };
            try {
                extractJSON.execute(new URL("https://pastebin.com/raw/fccygpHz"));
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
            return true;
        }

        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==REQUEST_CODE_ADD && resultCode==RESULT_OK && data!=null)
        {
            Student student = (Student) data.getSerializableExtra(AddActivity.ADD_STUDENT);
            if(student!=null)
            {
                listaStudenti.add(student);

                StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
                database.getStudentDao().insert(student);

              /*  ArrayAdapter<Student> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1, listaStudenti);*/
                CustomAdapter adapter = new CustomAdapter(getApplicationContext(),
                        R.layout.elem_listview, listaStudenti, getLayoutInflater())
                {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        View view = super.getView(position, convertView, parent);

                        Student student1 = listaStudenti.get(position);
                        TextView tvMedie = view.findViewById(R.id.tvMedie);
                        if(student1.getMedieAnuala()>=5)
                            tvMedie.setTextColor(Color.GREEN);
                        else
                            tvMedie.setTextColor(Color.RED);

                        return view;
                    }
                };

                listView.setAdapter(adapter);
            }
        }
        else
        if(requestCode==REQUEST_CODE_EDIT && resultCode==RESULT_OK && data!=null)
        {
            Student student = (Student) data.getSerializableExtra(AddActivity.ADD_STUDENT);
            if(student!=null)
            {
                listaStudenti.get(poz).setNumeStudent(student.getNumeStudent());
                listaStudenti.get(poz).setDataNasterii(student.getDataNasterii());
                listaStudenti.get(poz).setMedieAnuala(student.getMedieAnuala());
                listaStudenti.get(poz).setFacultate(student.getFacultate());
                listaStudenti.get(poz).setAnStudiu(student.getAnStudiu());

                StudentiDB database = StudentiDB.getInstanta(getApplicationContext());
                database.getStudentDao().update(listaStudenti.get(poz));

               /* ArrayAdapter<Student> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1, listaStudenti);*/
                CustomAdapter adapter = (CustomAdapter)listView.getAdapter();
                adapter.notifyDataSetChanged();
            }
        }
    }
}