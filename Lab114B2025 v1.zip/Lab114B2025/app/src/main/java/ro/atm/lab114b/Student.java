package ro.atm.lab114b;

import java.util.Date;

public class Student {

    private String numeStudent;
    private Date dataNasterii;
    private float medieAnuala;
    private String facultate; //Calculatoare, Electronica, Comunicatii
    private String anStudiu; //1, 2, 3, 4

    public Student(String numeStudent, Date dataNasterii, float medieAnuala, String facultate, String anStudiu) {
        this.numeStudent = numeStudent;
        this.dataNasterii = dataNasterii;
        this.medieAnuala = medieAnuala;
        this.facultate = facultate;
        this.anStudiu = anStudiu;
    }

    public String getNumeStudent() {
        return numeStudent;
    }

    public void setNumeStudent(String numeStudent) {
        this.numeStudent = numeStudent;
    }

    public Date getDataNasterii() {
        return dataNasterii;
    }

    public void setDataNasterii(Date dataNasterii) {
        this.dataNasterii = dataNasterii;
    }

    public float getMedieAnuala() {
        return medieAnuala;
    }

    public void setMedieAnuala(float medieAnuala) {
        this.medieAnuala = medieAnuala;
    }

    public String getFacultate() {
        return facultate;
    }

    public void setFacultate(String facultate) {
        this.facultate = facultate;
    }

    public String getAnStudiu() {
        return anStudiu;
    }

    public void setAnStudiu(String anStudiu) {
        this.anStudiu = anStudiu;
    }

    @Override
    public String toString() {
        return "Student{" +
                "numeStudent='" + numeStudent + '\'' +
                ", dataNasterii=" + dataNasterii +
                ", medieAnuala=" + medieAnuala +
                ", facultate='" + facultate + '\'' +
                ", anStudiu='" + anStudiu + '\'' +
                '}';
    }
}
