package ro.atm.lab114b;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_STUDENT = "addStudent";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add);
        /*ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });*/

        Intent intent = getIntent();

        String[] facultati = {"Calculatoare", "Electronica", "Comunicatii"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                facultati);
        Spinner spinnerFacultati = findViewById(R.id.spinnerFacultate);
        spinnerFacultati.setAdapter(adapter);

        EditText etNume = findViewById(R.id.editTextNume);
        EditText etData = findViewById(R.id.editTextDate);
        EditText etMedie = findViewById(R.id.editTextMedie);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        if(intent.hasExtra(MainActivity.EDIT_STUDENT))
        {
            Student student = (Student) intent.getSerializableExtra(MainActivity.EDIT_STUDENT);
            etNume.setText(student.getNumeStudent());
            etData.setText(new SimpleDateFormat("MM/dd/yyyy", Locale.US).
                    format(student.getDataNasterii()));
            etMedie.setText(student.getMedieAnuala()+"");
            ArrayAdapter<String> adapter1 = (ArrayAdapter<String>) spinnerFacultati.getAdapter();
            for(int i=0;i<adapter1.getCount();i++)
                if(adapter1.getItem(i).equals(student.getFacultate()))
                {
                    spinnerFacultati.setSelection(i);
                    break;
                }
            if(student.getAnStudiu().equals("1"))
                radioGroup.check(R.id.radioButton1);
            else
            if(student.getAnStudiu().equals("2"))
                radioGroup.check(R.id.radioButton2);
            else
            if(student.getAnStudiu().equals("3"))
                radioGroup.check(R.id.radioButton3);
            else
            if(student.getAnStudiu().equals("4"))
                radioGroup.check(R.id.radioButton4);
        }

        Button btnCreare = findViewById(R.id.btnCreare);
        if(intent.hasExtra(MainActivity.EDIT_STUDENT))
            btnCreare.setText("Editare student");
        btnCreare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etNume.getText().toString().isEmpty())
                    etNume.setError("Introduceti numele!");
                else
                    if(etData.getText().toString().isEmpty())
                        etData.setError("Introduceti data nasterii!");
                    else
                        if(etMedie.getText().toString().isEmpty())
                            etMedie.setError("Introduceti media!");
                        else {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
                            try {
                                sdf.parse(etData.getText().toString());

                                Date dataNasterii = new Date(etData.getText().toString());
                                String numeStudent = etNume.getText().toString();
                                float medieAnuala = Float.parseFloat(etMedie.getText().toString());
                                String facultate = spinnerFacultati.getSelectedItem().toString();
                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                String anStudiu = radioButton.getText().toString();

                                Student student = new Student(numeStudent, dataNasterii, medieAnuala, facultate, anStudiu);
                                /*Toast.makeText(getApplicationContext(), student.toString(), Toast.LENGTH_SHORT).show();*/
                                intent.putExtra(ADD_STUDENT, student);
                                setResult(RESULT_OK, intent);
                                finish();

                            } catch (Exception e) {
                                Toast.makeText(getApplicationContext(), "Eroare introducere date!",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
            }
        });
    }
}