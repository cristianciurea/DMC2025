package ro.atm.lab114b;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class BNRActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_bnr);

        Log.e("lifecycle", "Apel metoda onCreate()");

      /*  ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });*/

        TextView tvData = findViewById(R.id.dataCurs);
        EditText etEUR = findViewById(R.id.editTextEUR);
        EditText etUSD = findViewById(R.id.editTextUSD);
        EditText etGBP = findViewById(R.id.editTextGBP);
        EditText etXAU = findViewById(R.id.editTextXAU);
        Button btnAfisare = findViewById(R.id.btnAfisare);
        btnAfisare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*tvData.setText("2025-02-26");
                etEUR.setText("4.99");
                etUSD.setText("4.89");
                etGBP.setText("6.25");
                etXAU.setText("423.90");
                Toast.makeText(getApplicationContext(), "Curs valutar afisat!",
                        Toast.LENGTH_LONG).show();*/
                Network network = new Network()
                {
                    @Override
                    protected void onPostExecute(InputStream inputStream) {
                        /*Toast.makeText(getApplicationContext(),
                                Network.rezultat, Toast.LENGTH_LONG).show();*/
                        tvData.setText(cv.getDataCurs());
                        etEUR.setText(cv.getEuro());
                        etUSD.setText(cv.getDolar());
                        etGBP.setText(cv.getLira());
                        etXAU.setText(cv.getAur());
                    }
                };
                try {
                    network.execute(new URL("https://www.bnr.ro/nbrfxrates.xml"));
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        Button btnSalvare = findViewById(R.id.btnSalvare);
        btnSalvare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CursValutar cursValutar1 = new CursValutar(tvData.getText().toString(),
                        etEUR.getText().toString(), etUSD.getText().toString(),
                        etGBP.getText().toString(), etXAU.getText().toString());

                try {
                    writeToFile("fisier.dat", cursValutar1);
                    cursValutar1 = null;
                    cursValutar1 = readFromFile("fisier.dat");
                    Toast.makeText(getApplicationContext(), cursValutar1.toString(),
                            Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("lifecycle", "Apel metoda onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("lifecycle", "Apel metoda onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("lifecycle", "Apel metoda onPause()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e("lifecycle", "Apel metoda onRestart()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("lifecycle", "Apel metoda onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("lifecycle", "Apel metoda onDestroy()");
    }

    @Override
    public void onClick(View view) {

    }

    public void writeToFile(String fileName, CursValutar cv) throws IOException {
        FileOutputStream fileOutputStream = openFileOutput(fileName, Activity.MODE_PRIVATE);
        DataOutputStream dos = new DataOutputStream(fileOutputStream);
        dos.writeUTF(cv.getDataCurs());
        dos.writeUTF(cv.getEuro());
        dos.writeUTF(cv.getDolar());
        dos.writeUTF(cv.getLira());
        dos.writeUTF(cv.getAur());
        dos.flush();
        fileOutputStream.close();
    }

    public CursValutar readFromFile(String fileName) throws IOException
    {
        FileInputStream fileInputStream = openFileInput(fileName);
        DataInputStream dis = new DataInputStream(fileInputStream);
        String data = dis.readUTF();
        String euro = dis.readUTF();
        String dolar = dis.readUTF();
        String lira = dis.readUTF();
        String aur = dis.readUTF();
        CursValutar cursValutar = new CursValutar(data, euro, dolar, lira, aur);
        fileInputStream.close();
        return cursValutar;
    }
}