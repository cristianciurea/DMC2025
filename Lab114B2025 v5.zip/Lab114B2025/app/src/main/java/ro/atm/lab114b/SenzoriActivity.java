package ro.atm.lab114b;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.Nullable;

public class SenzoriActivity extends Activity {

    TextView tvLog = null;
    Button btnSenzori = null;

    SensorManager sm = null;
    Sensor s = null;
    SenzoriListener sl = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView sv = new ScrollView(this);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);

        tvLog = new TextView(this);
        btnSenzori = new Button(this);
        btnSenzori.setText("Senzori");
        btnSenzori.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sm.unregisterListener(sl);
                sm.registerListener(sl, s, SensorManager.SENSOR_DELAY_UI);
                tvLog.setText("");
            }
        });

        ll.addView(btnSenzori);
        ll.addView(tvLog);
        sv.addView(ll);
        setContentView(sv);

        sl = new SenzoriListener();
        sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        List<Sensor> sensorList = sm.getSensorList(Sensor.TYPE_LIGHT);
        s = sensorList.get(0);

    }

    class SenzoriListener implements SensorEventListener
    {

        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            /*tvLog.append("Coordonatele pe cele 3 axe:\r\n");
            tvLog.append("X: "+sensorEvent.values[0]);
            tvLog.append(" Y: "+sensorEvent.values[1]);
            tvLog.append(" Z: "+sensorEvent.values[2]);*/
            tvLog.append("Luminozitatea: \r\n");
            tvLog.append(""+sensorEvent.values[0]);
            tvLog.append("\r\n");
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    }
}
