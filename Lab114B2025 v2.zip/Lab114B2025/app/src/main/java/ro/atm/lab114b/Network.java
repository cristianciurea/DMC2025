package ro.atm.lab114b;

import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Network extends AsyncTask<URL, Void, InputStream> {

    InputStream ist = null;
    static String rezultat = null;

    @Override
    protected InputStream doInBackground(URL... urls) {

        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) urls[0].openConnection();
            connection.setRequestMethod("GET");

            ist = connection.getInputStream();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return null;
    }
}
